$(document).ready(function() {
	var occurencesCounter=1;
	var endDate=new Date();
		$('.form_date').datetimepicker({
			weekStart: 1,
			todayBtn:  0,
			autoclose: 1,
			todayHighlight: 0,
			startView: 2,
			minView: 2,
			forceParse: 0,
			 endDate: '+0d'
		});
			 // caluculate height for dog image for mobile 
			 var heightValue=0;
			 heightCalculator();
			 //code for fixed header start
			var headerHeightValue=0;
			$(window).load(function(){
				headerHeightCalculator();
				heightCalculator();
			});
			
			//code for fixed header end
			$(window).resize(function(){
			   heightCalculator();
			   
				//code for fixed header start
				headerHeightCalculator();
			  //code for fixed header end
			});
			function heightCalculator(){
				 heightValue=$('.gel-section .features').height();				
				$('.dog-image-container img').css('height',heightValue);				
			}
			//code for setting margin-top due to fixed header
			
		//code for fixed header start
			function headerHeightCalculator(){
				headerHeightValue=$('header').outerHeight();
				$('.gel-section').css('margin-top',headerHeightValue);			
			}
		//code for fixed header end
			
			// add more occurneces
			$(document).on("click",".add-more-occurences",function(event){	
				occurencesCounter=occurencesCounter+1;
				console.log(occurencesCounter);
				if(occurencesCounter<4){

					var txt="<div class='date-item'>"+
						"<div class='input-group date form_date' data-date='' data-date-format='MM dd, yyyy' data-link-field='date"+occurencesCounter+"' data-link-format='yyyy-mm-dd'>"+
						"<input class='form-control' size='16' type='text' value='' readonly>"+
						"<span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span></span><input type='hidden' id='date"+occurencesCounter+"' value='' /></div>";
						
					$('.infection-occurences .date-list').append(txt);	
					$('.form_date').datetimepicker({
						weekStart: 1,
						todayBtn:  0,
						autoclose: 1,
						todayHighlight: 0,
						startView: 2,
						minView: 2,
						forceParse: 0,
						 endDate: '+0d'
					});					
				}
				else{
					$('.add-more-occurences span').css('ponter-events','none');
				}							
				  
				});
				
			//dropdown selection
			$('#infect li').bind("click", function(){ 
				var valueOfSelection=$(this).text();
				$(this).parent().parent().find('p').text(valueOfSelection);
				$(this).parent().removeClass('collapse in');
				$(this).parent().addClass('collapse');
			});

			//scroll on click of navigation menu links
			$('.nav-link-wrapper a').click(function () {
				$('html, body').animate({
					/*if header is fixed start*/
					scrollTop: $($(this).attr('href')).offset().top-headerHeightValue
					/*if header is fixed end*/
					//scrollTop: $($(this).attr('href')).offset().top
				}, 500);
				return false;
			});

			//change of checkbox iamge on click
			$('.chkbox-container span,.chkbox-container p').click(function(){
				$(this).parent().toggleClass('optionSelected');	
				if($(this).parent().hasClass('optionSelected')){
					$(this).parent().find('img').attr('src','img/chk-chkbox.png');		
				}
				else{
					$(this).parent().find('img').attr('src','img/chkbox.png');			
				}
				
			});
			//print
			$('.print').click(function(){
				
				var w = window.open();
				var html = $(".print-section").html();
				var text="<style>@media print{@page{size: auto;margin: 0mm;}}</style>"

				$(w.document.body).html(html+text);
				w.print();
				//$(w.document.body).html("");
				
			});

			//summary generation close button
			/*new*/
			$('.close-summary span').click(function(){
			/*new end*/
				$('.form-summary').hide();
				$('.ask-vet-dog-container img').css('margin-top','0');
				$('.ask-vet-dog-container img').css('margin-left','auto');
				$('.ask-vet-dog-container img').css('margin-right','auto');
				setTimeout(function(){ 
					$('.summary-form').show(); 
					$(window).scrollTop($('.summary-form').offset().top-headerHeightValue);
				}, 50);
				

			});
			
			//back to summary
			
			/*new*/
			$('.close-email-msg span').click(function(){
				$('.email-thank-you').hide();
				$('.form-summary').show();
				
			});	

			$('.email-panel span').click(function(){
				/*new*/
				var summHeight=$('.form-summary').height();
				$('.email-thank-you').css('min-height',summHeight);
				/*new end*/
				$('.form-summary').hide();
				$('.email-thank-you').show();
				$(window).scrollTop($('.email-thank-you').offset().top-headerHeightValue);
				
			});			
			/*new end*/
			//summary generation
			$('.submit-container span').click(function(){
				$('.ask-vet-dog-container img').css('margin-top','-50px');
				//$('header').css('position','static');
				//$('.gel-section').css('margin-top','0 !important');
				$('.ask-vet').css('z-index','9');
				var symptomString="",seasonString="",dateString="";			
				$('.date-item').each(function(i, obj) {					
					var dateValue=$(this).children('div').children('input').val();
					console.log(dateValue);
					dateString=dateString+dateValue +', ';
					
				});
				var noOfEarInfections= $('.infection-number .dropdown p').text().replace(/\s|&nbsp;/g, '');
				var infectionString="";
				if(noOfEarInfections==1){
					infecttionString= noOfEarInfections + ' ear infection per year';
				}
				else if(noOfEarInfections>=2 && noOfEarInfections<=4){					
					infecttionString= noOfEarInfections + ' ear infections per year';
				}
				else{
					infecttionString= 'More than 5 ear infections per year';
				}
						
				$('.signs-select-list .optionSelected').each(function(i, obj) {
					var symptom=$(obj).find('p').text();
					if(symptom!=""){
						symptomString=symptomString + symptom +', ';	
					}
					else{
						symptomString=symptomString;
					}				
					
				
				});
				$('.seasons-select-list .optionSelected').each(function(i, obj) {
					var season=$(obj).find('p').text();
					
					if(season!=""){
						seasonString=seasonString+ season +', ';
					}

					else{
						seasonString=seasonString;
					}
				
				});
				 dateString = dateString.substr(0, dateString.length-2);

				if(symptomString==""){
						symptomString="";
				}
				else if(symptomString.lastIndexOf(',')== symptomString.indexOf(',')){
					symptomString=symptomString.substr(0, symptomString.length-2);
				}
				else{
					symptomString=symptomString.substr(0, symptomString.length-2);
				 symptomString = symptomString.slice( 0, symptomString.lastIndexOf( "," ) ) + " and"  + symptomString.substring( symptomString.lastIndexOf( "," )+1 );
				}
				if(seasonString==""){
						seasonString="";
				}
				else if(seasonString.lastIndexOf(',')== seasonString.indexOf(',')){
					seasonString=seasonString.substr(0, seasonString.length-2);
				}
				else{

					 seasonString=seasonString.substr(0, seasonString.length-2);
				 seasonString = seasonString.slice( 0, seasonString.lastIndexOf( "," ) ) + " and"  + seasonString.substring( seasonString.lastIndexOf( "," )+1 );
				}
				$('.summary-form').hide();
				$('.sum-dates').text('').text(dateString);
				$('.sum-symptoms').text('').text(symptomString);
				$('.sum-infections').text('').text(infecttionString);
				$('.sum-seasons').text('').text(seasonString);
				$('.form-summary').show();
				
				$(window).scrollTop($('.form-summary').offset().top-headerHeightValue);
				
				

			});
			
			// function isScrolledIntoView(elem)
// {
			// var docViewTop = $(window).scrollTop();
			// var docViewBottom = docViewTop + $(window).height();
			// var elemTop = $(elem).offset().top-headerHeightValue;
			// var elemBottom = elemTop + $(elem).height();
			
			// return ((elemBottom >= docViewTop) && (elemTop <= docViewBottom) && (elemBottom <= docViewBottom) && (elemTop >= docViewTop));
		// }

		// $(window).scroll(function() {    
			// if(isScrolledIntoView($('#gel')))
			// {
				// $('#nor').hide();
				
				// $('#anim').show();
				// console.log('yes');
			// }    
			
		// });
		$(window).scroll(function () {
			var offset = $("#gel").offset().top-headerHeightValue;
			var offset2=offset+$("#gel").outerHeight();
			
			if (($(window).scrollTop() >= offset)&&($(window).scrollTop() < offset2)) {
				
				$('#nor').attr('src','img/Osurnia_Animation.gif');
				
				console.log('in');
			}else{
				$('#nor').attr('src','img/animation.jpg');
				console.log('out');
			}			
		});
		
		
		  
        });

		
		
		
		
		
		